#include "rtos/scheduler.h"
#include "rtos/task.h"
#include <pthread.h>
#include <stdio.h>

#define NUM_CORES 2

// 示例任务函数
void sample_task(void* param) {
    const char* name = (const char*)param;
    printf("✅ 任务 %s 执行完毕\n", name);
}

int main() {
    printf("🧠 Mini RTOS 启动...\n");

    task_init();

    // 创建任务（名称, 函数, 参数, 所属核心, 周期, 优先级, 初始状态）
    task_create("Task A", sample_task, "A", 0, 3, 1, 0);
    task_create("Task B", sample_task, "B", 1, 5, 2, 1);

    // 启动两个核心的调度器
    pthread_t cores[NUM_CORES];
    int ids[NUM_CORES] = {0, 1};
    for (int i = 0; i < NUM_CORES; i++) {
        pthread_create(&cores[i], NULL, (void*)scheduler_loop, &ids[i]);
    }
    for (int i = 0; i < NUM_CORES; i++) {
        pthread_join(cores[i], NULL);
    }

    return 0;
}
