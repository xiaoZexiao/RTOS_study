#ifndef RTOS_CONFIG_H
#define RTOS_CONFIG_H

#define MAX_TASKS 10
#define NUM_CORES 2
#define MEMORY_POOL_SIZE 1024

#endif
