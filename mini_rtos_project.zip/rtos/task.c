#include "task.h"
#include <string.h>

#define MAX_TASKS 10

static TaskControlBlock taskList[MAX_TASKS];
static int taskCount = 0;

void task_init() {
    taskCount = 0;
}

void task_create(const char* name, void (*func)(void*), void* param,
                 int core, int period, int priority, int id) {
    if (taskCount < MAX_TASKS) {
        TaskControlBlock* t = &taskList[taskCount++];
        strncpy(t->name, name, sizeof(t->name));
        t->taskFunc = func;
        t->parameter = param;
        t->affinity = core;
        t->period = period;
        t->priority = priority;
        t->delay = 0;
        t->state = READY;
        t->id = id;
        t->executionCount = 0;
    }
}

TaskControlBlock* task_get_ready(int core_id) {
    TaskControlBlock* selected = NULL;
    for (int i = 0; i < taskCount; i++) {
        TaskControlBlock* t = &taskList[i];
        if (t->affinity == core_id && t->state == READY) {
            if (!selected || t->priority < selected->priority) {
                selected = t;
            }
        }
    }
    return selected;
}

void task_tick_update() {
    for (int i = 0; i < taskCount; i++) {
        if (taskList[i].state == SLEEPING) {
            taskList[i].delay--;
            if (taskList[i].delay <= 0) {
                taskList[i].state = READY;
            }
        }
    }
}
