#ifndef SCHEDULER_H
#define SCHEDULER_H

void scheduler_loop(int core_id); // 每个核心的调度循环

#endif
