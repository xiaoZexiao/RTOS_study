#ifndef TASK_H
#define TASK_H

typedef enum { READY, RUNNING, SLEEPING } TaskState;

typedef struct {
    char name[32];               // 任务名称
    int id;                      // 任务ID
    int delay;                   // 延迟时间
    int period;                  // 运行周期
    int priority;                // 优先级（值越小优先级越高）
    int affinity;                // 所属核心编号
    int executionCount;          // 执行次数
    TaskState state;             // 当前状态
    void (*taskFunc)(void*);     // 任务函数指针
    void* parameter;             // 参数
} TaskControlBlock;

void task_init();                                 // 初始化任务系统
void task_create(const char* name, void (*func)(void*), void* param,
                 int core, int period, int priority, int id); // 创建任务
TaskControlBlock* task_get_ready(int core_id);    // 获取当前核心可运行任务
void task_tick_update();                          // 所有任务tick更新

#endif
