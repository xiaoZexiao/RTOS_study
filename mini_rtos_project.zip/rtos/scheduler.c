#include "scheduler.h"
#include "task.h"
#include <stdio.h>
#include <unistd.h>

// 核心调度器主循环
void scheduler_loop(int core_id) {
    while (1) {
        TaskControlBlock* t = task_get_ready(core_id);
        if (t) {
            t->state = RUNNING;
            printf("▶️ [Core %d] 运行任务：%s\n", core_id, t->name);
            t->taskFunc(t->parameter);
            t->executionCount++;
            t->delay = t->period;
            t->state = SLEEPING;
        } else {
            printf("💤 [Core %d] 空闲中...\n", core_id);
        }

        sleep(1);
        task_tick_update();
    }
}
